import { hydrate } from "bun-react-ssr/hydrate";
import { ExampleShell } from "./shell";

await hydrate(ExampleShell);