import { StaticRouters } from "bun-react-ssr";

export const router = new StaticRouters(import.meta.dir);
