export type _Users = {
id?: number;
username: string;
password: string;
createdAt: Date;
};